bazel test test:hello-test
